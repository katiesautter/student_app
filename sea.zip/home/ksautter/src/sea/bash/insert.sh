#!/bin/bash
psql -U ksautter -d sea <<EOF
INSERT INTO users VALUES ('1', 'katiesautter', 'Horses12'); 

INSERT INTO users VALUES ('2', 'babydragon', 'dragons10'); 

INSERT INTO users VALUES ('3', 'beccathorne', 'buckyb'); 

INSERT INTO users VALUES ('4', 'codycook', 'bigbear27'); 

INSERT INTO posts VALUES ('1', 'Come to our Shrader Game Night', '2', '1'); 

INSERT INTO posts VALUES ('4', 'Lax Night', '1', '5'); 

INSERT INTO posts VALUES ('2', 'Capture the Flag', '1', '2'); 

INSERT INTO posts VALUES ('3', 'Capture the Flag', '1', '2'); 

INSERT INTO events VALUES ('1', 'Game Night', 'public', current_timestamp, '1'); 

INSERT INTO events VALUES ('2', 'Capture the Flag', 'public', current_timestamp, '2'); 

INSERT INTO events VALUES ('3', 'Movie Night', 'private', current_timestamp, '1'); 

INSERT INTO events VALUES ('4', 'Talent Show', 'private', current_timestamp, '2'); 

INSERT INTO events VALUES ('5', 'Lacrosse Night!', 'private', current_timestamp, '2'); 

INSERT INTO locations VALUES ('1', 'Shrader');

INSERT INTO locations VALUES ('2', 'Wolly lawn');

INSERT INTO private_events_users VALUES ('1', '2', '3');
EOF
